/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package airline_managemant_system;

import java.sql.*;


public class Conn {
    // object
    Connection c;
    Statement s;
    
    public Conn(){
    try{
        Class.forName("com.mysql.cj.jdbc.Driver");
        c = DriverManager.getConnection("jdbc:mysql:///airlinemanagementsystem", "root", "tiger");
        s = c.createStatement();
    } catch (Exception e){
        e.printStackTrace();
    }
    
    }
}


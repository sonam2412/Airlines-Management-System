/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package airline_managemant_system;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class Login extends JFrame implements ActionListener{
    
    // globaly declaration 
    JButton submit, reset, close;
    JTextField tfusername;
    JPasswordField tfpassword;
    
    
    public Login(){
        
        getContentPane().setBackground(Color.WHITE);
        setLayout(null);
        
        //  Locally declaration :- 
        
        // login 
        JLabel lblusername = new JLabel("username");
        lblusername.setBounds(20, 20, 100, 20);
        add(lblusername);
        
        // create box to inter the text content
        tfusername = new JTextField();
        tfusername.setBounds(130,20,200,20);
        add(tfusername);
        
        // password
        JLabel lblpassword = new JLabel("password");
        lblpassword.setBounds(20, 60, 100, 20);
        add(lblpassword);
        
         // create box to inter the password
        tfpassword = new JPasswordField();
        tfpassword.setBounds(130,60,200,20);
        add(tfpassword);
        
        // create button - create any types of button use "JButton". in this constructor your button is locally declare
        
        // reset button 
        reset = new JButton("Reset");
        reset.setBounds(40, 120, 120, 20);
        reset.addActionListener(this);
        add(reset);
        
         // reset submit 
        submit = new JButton("submit");
        submit.setBounds(190, 120, 120, 20);
        submit.addActionListener(this);
        add(submit);
        
         // reset close 
        close = new JButton("close");
        close.setBounds(120, 160, 120, 20);
        close.addActionListener(this);
        add(close);
        
        // frame creation 
        setSize(400, 500);
        setLocation(900, 200);
        setVisible(true);
    }
    
    // all button perform a action
    @Override
    public void actionPerformed(ActionEvent ae){
        if(ae.getSource() == submit){
            String username = tfusername.getText();
            String password = tfpassword.getText();
            
            try{
                Conn c = new Conn();
                
                String query = "select * from login where username = '"+username+"' and password = '"+password+"'";
                
                ResultSet rs = c.s.executeQuery(query);
                
                // check username and password is valid or invalid
                if (rs.next()){
                    // you open new page
                    new Home();
                    setVisible(false);
                } else{
                    // username and password is invalid 
                    JOptionPane.showMessageDialog(null, "Invalid username and password");
                    setVisible(false); 
                }
                
            }catch (Exception e){
                e.printStackTrace();
            }
            
        } else if(ae.getSource() == close){
            setVisible(false); // you can click the close button your frame is close  
        } else if (ae.getSource() == reset){
            tfusername.setText(""); // you can click the reset button you frame will be empty.
            tfpassword.setText("");
        }
    }
    
    public static void main(String args[]){
        new Login();
       
    }
    
}

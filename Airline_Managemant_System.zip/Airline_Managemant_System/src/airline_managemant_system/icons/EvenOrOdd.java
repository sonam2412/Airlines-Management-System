
package airline_managemant_system.icons;

import java.util.Scanner;

public class EvenOrOdd {
    
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);  
        System.out.println("enter your number");
        int n = s.nextInt();
        
        if (n % 2 == 0) {  // Correct condition for even
            System.out.println("even value");
        } else {
            System.out.println("odd value");  // Corrected typo
        }
        
    }
    
}
